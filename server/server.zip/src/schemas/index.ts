// index.ts
export { default as typeDefs } from './typeDefs.js';
export { default as resolvers } from './resolvers.js';

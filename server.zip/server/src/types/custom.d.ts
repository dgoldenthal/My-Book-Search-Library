declare module 'dotenv';
declare module 'bcrypt';
declare module 'jsonwebtoken';
